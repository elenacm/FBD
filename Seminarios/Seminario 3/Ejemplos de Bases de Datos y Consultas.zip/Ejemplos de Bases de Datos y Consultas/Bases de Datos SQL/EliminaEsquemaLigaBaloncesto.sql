-- Elimina BD Liga de Baloncesto
DROP TABLE Faltas;
DROP TABLE Encuentros;
DROP TABLE Jugadores;
DROP TABLE Equipos;