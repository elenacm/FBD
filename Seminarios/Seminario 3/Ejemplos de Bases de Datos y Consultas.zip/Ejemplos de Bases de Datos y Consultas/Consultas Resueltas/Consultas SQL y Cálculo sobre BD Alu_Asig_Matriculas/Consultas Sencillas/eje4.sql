-- Muestra ordenados los curriculum ditintos que hay

select distinct curriculum  from asigna order by curriculum;

