-- N�mero m�ximo y m�nimo de cr�ditos por asignatura

select min(credt+credpr),max(credt+credpr)  from asigna;
