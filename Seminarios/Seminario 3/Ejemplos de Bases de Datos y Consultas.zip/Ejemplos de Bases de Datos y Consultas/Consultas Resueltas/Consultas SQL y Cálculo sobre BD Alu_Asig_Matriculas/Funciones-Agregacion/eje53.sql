-- Matr�culas con calificaci�n no nula (coincide con el n�mero total de matr�culas)

Select count(calificacion) from matricula;

