-- N�mero de tuplas de la tabla matr�cula

select count(*) from matricula;

