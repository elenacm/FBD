--Asignaturas con mayor n�mero de cr�ditos

select asi#,nombreas,credt+credpr creditos from asigna where
 (credt+credpr)=(select max(credt+credpr) from asigna);
 
-- C�culo WinRDBI: Asignaturas con mayor n�mero de cr�ditos pr�cticos
query:= { A |  asigna(A) and  not (exists A1)(asigna(A1) and A1.credpr>A.credpr )};

