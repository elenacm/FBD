-- Mostrar los datos del alumno con dni 242856'
select ape1,ape2,nombre,edad from alumnos where dni='242856';
