-- Alumnos menores de 25 a�os ordenados por edad (descendente) y por apellidos y nombre

select nombre,ape1,ape2 from alumnos 
where edad <=25 order by edad desc, ape1,ape2,nombre;

