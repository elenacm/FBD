-- Alumnos que han aprobado todas las asignaturas del grado en Informática (Dos alternativas de solución)

 Select ape1,ape2,nombre from alumnos al where
      not exists (select a.asi# from asigna a where curriculum='Grado Informatica'  
                   minus
                  select m.codasi# from matricula m where al.dni=m.dni  
                                      and calificacion in ('ap','no','sb','mh'));
  
 Select ape1,ape2,nombre from alumnos al where
      not exists (select * from asigna a where curriculum='Grado Informatica'  and
         not exists (select * from matricula m where al.dni=m.dni and m.codasi#=a.asi# 
                     and calificacion in ('ap','no','sb','mh')));
