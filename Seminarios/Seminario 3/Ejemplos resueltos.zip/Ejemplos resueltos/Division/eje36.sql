--Asignaturas que tiene o han tenido matriculados todos los alumnos de Almería

Select asi#,nombreas from asigna a where 
   not exists(select dni from alumnos  where provincia='Almeria'
               minus
              select m.dni from matricula m where m.codasi#=a.asi#);
