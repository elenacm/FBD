--Alumnos becarios matriculados de todas las asignaturas de seis o más créditos (otra versión)

select ape1,ape2,nombre from alumnos al where beca='si' and not exists
      (select a.asi# from asigna  a where credt+credpr>6 
         minus
       select m.codasi# from matricula m where al.dni=m.dni);
