-- Numero m?ximo y minimo de creditos por asignatura

select min(credt+credpr),max(credt+credpr)  from asigna
/
