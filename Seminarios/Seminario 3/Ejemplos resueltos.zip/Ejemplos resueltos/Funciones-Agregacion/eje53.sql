-- Matriculas con calificacion no nula (coincide con el n?mero total de matriculas

Select count(calificacion) from matricula

/
