-- Numero de instancias de la tabla matricula

select count(*) from matricula
/
