
REM INSERTING into PROVEEDOR
SET DEFINE OFF;
Insert into PROVEEDOR (CODPRO,NOMPRO,STATUS,CIUDAD) values ('S1 ','Jose Fernandez',2,'Madrid');
Insert into PROVEEDOR (CODPRO,NOMPRO,STATUS,CIUDAD) values ('S2 ','Manuel Vidal',1,'Londres');
Insert into PROVEEDOR (CODPRO,NOMPRO,STATUS,CIUDAD) values ('S3 ','Luisa Gomez',3,'Lisboa');
Insert into PROVEEDOR (CODPRO,NOMPRO,STATUS,CIUDAD) values ('S4 ','Pedro Sanchez',4,'Paris');
Insert into PROVEEDOR (CODPRO,NOMPRO,STATUS,CIUDAD) values ('S5 ','Maria Reyes',5,'Roma');
REM INSERTING into PROYECTO
SET DEFINE OFF;
Insert into PROYECTO (CODPJ,NOMPJ,CIUDAD) values ('J1 ','Proyecto 1','Londres');
Insert into PROYECTO (CODPJ,NOMPJ,CIUDAD) values ('J2 ','Proyecto 2','Londres');
Insert into PROYECTO (CODPJ,NOMPJ,CIUDAD) values ('J3 ','Proyecto 3','Paris');
Insert into PROYECTO (CODPJ,NOMPJ,CIUDAD) values ('J4 ','Proyecto 4','Roma');
REM INSERTING into PIEZA
SET DEFINE OFF;
Insert into PIEZA (CODPIE,NOMPIE,COLOR,PESO,CIUDAD) values ('P1 ','Tuerca','Gris',2.5,'Madrid');
Insert into PIEZA (CODPIE,NOMPIE,COLOR,PESO,CIUDAD) values ('P2 ','Tornillo','Rojo',1.25,'Paris');
Insert into PIEZA (CODPIE,NOMPIE,COLOR,PESO,CIUDAD) values ('P3 ','Arandela','Blanco',3,'Londres');
Insert into PIEZA (CODPIE,NOMPIE,COLOR,PESO,CIUDAD) values ('P4 ','Clavo','Gris',5.5,'Lisboa');
Insert into PIEZA (CODPIE,NOMPIE,COLOR,PESO,CIUDAD) values ('P5 ','Alcayata','Blanco',10,'Roma');
